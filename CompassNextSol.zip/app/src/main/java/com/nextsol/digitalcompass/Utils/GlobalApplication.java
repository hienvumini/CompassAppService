package com.nextsol.digitalcompass.Utils;

import android.app.Application;
import android.location.Location;

public class GlobalApplication extends Application {
    public Location location;

}
